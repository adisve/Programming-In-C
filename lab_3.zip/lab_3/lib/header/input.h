#ifndef INPUT_HEADER_FILE
#define INPUT_HEADER_FILE

int getnum(char* buffer);
void setname(char* user_name);
int check_answer(char* buffer, int a, int b, int type, int *user_input);

#endif